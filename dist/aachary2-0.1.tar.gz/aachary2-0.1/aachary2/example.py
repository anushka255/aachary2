def hello():
    print("Hello World v0.1")


def add(a, b):
    return a + b


def multiply(a, b):
    return a * b